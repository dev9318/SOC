# music-pattern-predictor
For Team NYC,
the final cleaned data set is in- cleaned_Input.csv
the code for execution can be found in Main.py
the project report is in- TeamNYC_Report  
